package com.busy.apis.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.busy.apis.entities.Destino;

public interface DestinoRepository extends JpaRepository<Destino, Long> {

}
