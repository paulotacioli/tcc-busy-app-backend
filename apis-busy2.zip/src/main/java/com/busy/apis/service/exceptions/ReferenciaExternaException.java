package com.busy.apis.service.exceptions;

public class ReferenciaExternaException extends RuntimeException{

private static final long serialVersionUID = 1L;
	
	public ReferenciaExternaException (String msg) {
		super(msg);
	}
}

