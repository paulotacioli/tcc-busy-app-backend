package com.busy.apis.service.exceptions;

public class ServidorPendenteAprovacaoException extends RuntimeException{

private static final long serialVersionUID = 1L;
	
	public ServidorPendenteAprovacaoException (String msg) {
		super(msg);
	}



}
