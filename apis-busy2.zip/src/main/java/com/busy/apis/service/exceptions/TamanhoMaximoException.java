package com.busy.apis.service.exceptions;

public class TamanhoMaximoException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public TamanhoMaximoException () {
		super ();
	}
}
