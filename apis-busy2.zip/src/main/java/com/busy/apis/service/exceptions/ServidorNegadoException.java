package com.busy.apis.service.exceptions;

public class ServidorNegadoException extends RuntimeException{

private static final long serialVersionUID = 1L;
	
	public ServidorNegadoException (String msg) {
		super(msg);
	}



}
