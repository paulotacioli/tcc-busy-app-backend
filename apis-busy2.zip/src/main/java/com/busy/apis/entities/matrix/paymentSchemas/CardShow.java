package com.busy.apis.entities.matrix.paymentSchemas;


public class CardShow {
	
	private String lastNumber;
	private String id;
	private String brand;

	public String getLastNumber() {
		return lastNumber;
	}
	public void setLastNumber(String lastNumber) {
		this.lastNumber = lastNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}


	
	
}
